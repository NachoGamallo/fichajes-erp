package com.empresa.fichajes.service;

import com.empresa.fichajes.model.Employee;
import com.empresa.fichajes.model.TimeRecord;
import com.empresa.fichajes.repository.TimeRecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.*;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class AttendanceService {

    @Autowired
    private TimeRecordRepository recordRepo;

    // Registrar fichaje
    public String processPunch(Employee emp, String action) {
        TimeRecord record = new TimeRecord();
        record.setEmployee(emp);
        record.setActionType(action);
        record.setTimestamp(LocalDateTime.now());
        recordRepo.save(record);

        DayOfWeek today = LocalDate.now().getDayOfWeek();
        if ((today == DayOfWeek.MONDAY || today == DayOfWeek.FRIDAY) && action.equals("CLOCK_IN")) {
            return "Punch recorded. ALERT: Outside schedule (Overtime).";
        }
        return "Punch recorded: " + action;
    }

    // Cálculo de estadísticas de los últimos 2 meses
    public Map<String, Object> getEmployeeStats(Long empId) {
        LocalDateTime twoMonthsAgo = LocalDateTime.now().minusMonths(2);
        List<TimeRecord> records = recordRepo.findByEmployee_IdAndTimestamp(empId, twoMonthsAgo);

        Map<LocalDate, List<TimeRecord>> dailyGroups = records.stream()
                .collect(Collectors.groupingBy(r -> r.getTimestamp().toLocalDate()));

        double totalWork = 0;
        double totalBreaks = 0;
        double totalExtra = 0;
        int lateness = 0;

        for (Map.Entry<LocalDate, List<TimeRecord>> entry : dailyGroups.entrySet()) {
            List<TimeRecord> dayRecords = entry.getValue();
            double work = calculateDayWork(dayRecords);
            double breaks = calculateDayBreaks(dayRecords);

            totalWork += work;
            totalBreaks += breaks;

            // Lógica de Horas Extra: si > 6h o si es Lunes/Viernes
            if (isOffDay(entry.getKey())) {
                totalExtra += work;
            } else if (work > 6.0) {
                totalExtra += (work - 6.0);
            }

            if (checkLateness(dayRecords)) lateness++;
        }

        int days = dailyGroups.size();
        return Map.of(
                "avgWork", days > 0 ? String.format("%.2f", totalWork / days) : "0",
                "avgBreak", days > 0 ? String.format("%.2f", totalBreaks / days) : "0",
                "avgExtra", days > 0 ? String.format("%.2f", totalExtra / days) : "0",
                "lateness", lateness,
                "daysWorked", days
        );
    }

    private double calculateDayWork(List<TimeRecord> records) {
        LocalDateTime in = null, out = null;
        for (TimeRecord r : records) {
            if (r.getActionType().equals("CLOCK_IN")) in = r.getTimestamp();
            if (r.getActionType().equals("CLOCK_OUT")) out = r.getTimestamp();
        }
        if (in != null && out != null) {
            long mins = Duration.between(in, out).toMinutes();
            return (mins / 60.0) - calculateDayBreaks(records);
        }
        return 0;
    }

    private double calculateDayBreaks(List<TimeRecord> records) {
        LocalDateTime bIn = null;
        long breakMins = 0;
        for (TimeRecord r : records) {
            if (r.getActionType().equals("BREAK_IN")) bIn = r.getTimestamp();
            if (r.getActionType().equals("BREAK_OUT") && bIn != null) {
                breakMins += Duration.between(bIn, r.getTimestamp()).toMinutes();
                bIn = null;
            }
        }
        return breakMins / 60.0;
    }

    private boolean isOffDay(LocalDate date) {
        return date.getDayOfWeek() == DayOfWeek.MONDAY || date.getDayOfWeek() == DayOfWeek.FRIDAY;
    }

    private boolean checkLateness(List<TimeRecord> records) {
        return records.stream()
                .filter(r -> r.getActionType().equals("CLOCK_IN"))
                .anyMatch(r -> r.getTimestamp().toLocalTime().isAfter(LocalTime.of(9, 0)));
    }
}
