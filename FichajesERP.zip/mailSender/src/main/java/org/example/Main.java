package org.example;

import jakarta.mail.*;

import java.io.File;
import java.io.InputStream;
import java.util.Properties;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {

    public static void main(String[] args) throws Exception {

        final Properties prop = new Properties();

        try (InputStream input = Main.class
                .getClassLoader()
                .getResourceAsStream("config.properties")) {

            if (input == null) {
                throw new RuntimeException("No se encontró config.properties");
            }

            prop.load(input);
        }

        // Create the Session with the user credentials
        Session mailSession = Session.getInstance(prop, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(prop.getProperty("mail.smtp.username"),
                        prop.getProperty("mail.smtp.password"));
            }
        });

        mailSession.setDebug(true);

        //Get the store object and connect to the current host using the specified username and password.
        Store store = mailSession.getStore("imaps");

        store.connect(
                prop.getProperty("mail.imaps.host"),
                prop.getProperty("mail.imap.username"),
                prop.getProperty("mail.imap.password")
        );

        //Get the folder  and open it
        Folder folder = store.getFolder("INBOX");
        folder.open(Folder.READ_ONLY);

        //Get the message
        Message[] messages = folder.getMessages();

        //Process the messages
        for ( int i = 0 ; i < messages.length ; i++ ){

            System.out.println("Message: " + (i + 1));
            System.out.println("From: " + messages);

        }

    }

}